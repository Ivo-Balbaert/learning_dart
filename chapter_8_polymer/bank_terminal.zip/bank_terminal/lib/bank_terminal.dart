library bank_terminal;

part 'bank_account.dart';
part 'person.dart';