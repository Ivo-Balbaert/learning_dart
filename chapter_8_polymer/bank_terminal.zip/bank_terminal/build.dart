import 'package:polymer/builder.dart';
        
main() {     
  build(entryPoints: ['web/bank_terminal.html']);
}